const fs = require('fs');
const path = require('path');
const express = require('express');
const app = express();

const port = 3001;

const filmesPath = path.join(__dirname, 'filmes.json');
const filmesData = fs.readFileSync(filmesPath, 'utf-8');
const filmes = JSON.parse(filmesData);

function criarTabela(filme) {
    return `
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Título</th>
                <th scope="col">Ano</th>
                <th scope="col">Diretor</th>
                <th scope="col">Gênero</th>
                <th scope="col">Cartaz</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><h5>${filme.título}</h5></td>
                <td><h5>${filme.ano}</h5></td>
                <td><h5>${filme.diretor}</h5></td>
                <td><h5>${filme.gênero}</h5></td>
                <td><img src="${filme.cartaz}" alt="${filme.título}" style="max-height: 150px;"></td>
            </tr>
        </tbody>
    </table>`;
}

app.get('/', (req, res) => {
    const tablesHtml = filmes.map(filme => criarTabela(filme)).join('');
    const pageHtmlPath = path.join(__dirname, 'dadosfilme.html');
    let pageHtml = fs.readFileSync(pageHtmlPath, 'utf-8');
    pageHtml = pageHtml.replace('{{tablesHtml}}', tablesHtml);
    res.send(pageHtml);
});

app.listen(port, () => {
    console.log(`Servidor iniciado em http://localhost:${port}`);
});
